arb = Arabic
b5c = Big-5 Chinese
frn = French
eng = English
gbc = GB Chinese
ger = German
ita = Italian
rom = Romanian
rus = Russian
spn = Spanish
ukr = Ukranian

If you see small boxes in place of characters, this could mean that you do not have the necessary character packs available on your operating system for the particular language.