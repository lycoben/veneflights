<?php
/**
#
 * Functins for showing and saving site configuration
#
 * @author Vince Wooll <sales@jomres.net>
#
 * @version Jomres 3
#
* @package Jomres
#
* @copyright	2005-2008 Vince Wooll
#
* This is not free software, please do not distribute it. For licencing information, please visit http://www.jomres.net/
* All rights reserved.
 */

// ################################################################
if (!defined('JPATH_BASE'))
	defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
else
	{
	if (file_exists(JPATH_BASE .'/includes/defines.php') )
		defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
	else
		defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
	}
// ################################################################


//-----------------------------
//-A S S I G N  U S E R S  ----
//-----------------------------

/**
#
 * Lists profiles, performing assignation functionality where valid
#
 */


function listMosUsers()
	{
	global $database;
	$option="com_jomres";
	if (isset($_POST['chosenHotel']))
		{
		if (!jomresCheckToken()) {trigger_error ("Invalid token", E_USER_ERROR);}
		$chosenHotels	  	= jomresGetParam( $_POST, 'chosenHotel', array() );
		$userid 			= intval( jomresGetParam( $_POST, 'userid', 0 ) );
		$isSuperPropertyManager = intval( jomresGetParam( $_POST, 'superpropertymanager', 0 ) );
		updateManagerIdToPropertyXrefTable($userid,$chosenHotels);
		$query = "UPDATE #__jomres_managers SET `pu` = '$isSuperPropertyManager' WHERE userid = '".(int)$userid."'";
		doInsertSql($query,'Updated Super Property Manager setting to '.$isSuperPropertyManager);
		}
	if (isset($_POST['accessLevel']) )
		{
		if (!jomresCheckToken()) {trigger_error ("Invalid token", E_USER_ERROR);}
		$accessLevel		= intval( jomresGetParam( $_POST, 'accessLevel', 0 ) );
		$userid 			= intval( jomresGetParam( $_POST, 'userid', 0 ) );
		$acsLvlStr="";
		if ($accessLevel == 1)
			$acsLvlStr=", pu='0'";
		$query = "UPDATE #__jomres_managers SET `access_level` = '$accessLevel' ".$acsLvlStr." WHERE userid = '".(int)$userid."'";
		doInsertSql($query,'Changed access level to '.$accessLevel);
		}

	$query="SELECT id,name,username FROM #__users";
	$userList = doSelectSql($query);
	$userRowInfo="";
	foreach($userList as $user)
		{
		$id=$user->id;
		$query="SELECT userid,currentproperty,access_level,pu,apikey FROM #__jomres_managers WHERE userid = '".(int)$id."'";
		$jomresUserList  = doSelectSql($query);
		$pu="0"; // Pu, flag that defines if a user is a super property manager.
		$bgcol="ffffff";
		if (count($jomresUserList)>0 )
			{
			$property_uid=0;
			$access_level="";
			$authorise="n";
			$img = "images/tick.png";

			foreach ($jomresUserList as $userdeets)
				{
				$property_uid= (int)$userdeets->currentproperty;
				$access_level= $userdeets->access_level;
				$pu = $userdeets->pu;
				$apikey = $userdeets->apikey;
				}
			if ($access_level=="1")
				$access_level=_JOMRES_COM_MR_ASSIGNUSER_LEVEL_RECEPTION;
			else
				$access_level=_JOMRES_COM_MR_ASSIGNUSER_LEVEL_ADMIN;

			$query="SELECT property_name FROM #__jomres_propertys WHERE propertys_uid = '".(int)$property_uid."'";
			$propertyList= doSelectSql($query);
			$propertyFound=count($propertyList);
			if ($propertyFound>0)
				{
				foreach ($propertyList as $property)
					{
					$property_name= $property->property_name;
					}
				}
			else
				{
				$bgcol="fc0000";
				$property_name='<font color="black"><b>Unknown<font></b>';
				}
 			}
		else
			{
			$authorise="y";
			$img = "images/publish_x.png";
			}
		$isSuperPropertyManager = _JOMRES_COM_MR_NO;
		if ($pu == "1")
			$isSuperPropertyManager = _JOMRES_COM_MR_YES;

		$userRowInfo.="<tr>
		<td class=\"jradmin_subheader_la\">".($user->id)."</td>";
		$userRowInfo.="<td class=\"jradmin_subheader_la\">".($user->name)."</td>";
		$userRowInfo.="<td class=\"jradmin_subheader_la\">".($user->username)."</td>";
		$userRowInfo.="<td class=\"jradmin_subheader_la\"><a href=\"index2.php?option=com_jomres&task=grantMosUser&userid=".$id."&grantAct=".$authorise."&username=".($user->username)."\"><img src=\"".$img."\" border=\"0\"></a></td>";
		if ($authorise=="n")
			{
			$userRowInfo.="<td bgcolor=\"#".$bgcol."\"  align=\"center\">".$property_name."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\"><a href=\"index2.php?option=com_jomres&task=changeUserHotel&userid=".$id."&username=".($user->username)."\"><img src=\"".$img."\" border=\"0\" ></a></td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">".$access_level."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\"><a href=\"index2.php?option=com_jomres&task=changeUserAccessLevel&userid=".$id."&username=".($user->username)."\"><img src=\"".$img."\" border=\"0\" ></a></td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">".$isSuperPropertyManager."</td>
			</tr>";
			$userRowInfo.='<tr><td class=\"jradmin_subheader_la\" colspan=\"9\">APIKEY: <input type="text" size="100" class="inputbox" name="apikey'.$id.'" value="'.$apikey.'" READONLY onclick="select_all(this)"/></td></tr>';
			}
		else
			{
			$userRowInfo.="<td class=\"jradmin_subheader_la\">"._JOMRES_COM_MR_ASSIGNUSER_NOTAPPLICABLE."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">"._JOMRES_COM_MR_ASSIGNUSER_NOTAPPLICABLE."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">"._JOMRES_COM_MR_ASSIGNUSER_NOTAPPLICABLE."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">"._JOMRES_COM_MR_ASSIGNUSER_NOTAPPLICABLE."</td>";
			$userRowInfo.="<td class=\"jradmin_subheader_la\">"._JOMRES_COM_MR_ASSIGNUSER_NOTAPPLICABLE."</td>
			</tr>";
			}
		}
	HTML_jomres::listMosUsers_html( $userRowInfo,$option );
	}



/**
#
 * Assigns a user to a property
#
 */
function changeUserHotel()
	{
	global $database;
	$userid = jomresGetParam( $_REQUEST, 'userid', '' );
	$username = jomresGetParam( $_REQUEST, 'username', '' );
	$yesno = array();
	$yesno[] = jomresHTML::makeOption( '0', _JOMRES_COM_MR_NO );
	$yesno[] = jomresHTML::makeOption( '1', _JOMRES_COM_MR_YES );
	// First lets get a list of the hotels
	$query="SELECT propertys_uid,property_name FROM #__jomres_propertys";
	$propertyList = doSelectSql($query);
	//$propertyIdArray[]='0';
	//$propertynameArray[]=_JOMRES_COM_MR_ASSIGNUSER_ANYPROPERTY;
	foreach ($propertyList as $property)
		{
		$propertyIdArray[]=$property->propertys_uid;
		$propertynameArray[]=$property->property_name;
		}
	$query="SELECT userid,username,access_level,pu FROM #__jomres_managers";
	$managerList= doSelectSql($query);
	$managersArray=array();
	foreach ($managerList as $m)
		{
		$managersArray[$m->userid]=$m->username;
		$superPropertyManager=$m->pu;
		$accessLevel=$m->access_level;
		}
	$query="SELECT access_level,pu FROM #__jomres_managers WHERE username='$username' LIMIT 1";
	$manager= doSelectSql($query);
	$superPropertyManager=0;
	$accessLevel=1;
	foreach ($manager as $m)
		{
		$superPropertyManager=$m->pu;
		$accessLevel=$m->access_level;
		}

	$query="SELECT manager_id,property_uid FROM #__jomres_managers_propertys_xref";
	$managersToPropertysList = doSelectSql($query);
	$managersToPropertysArray=array();
	foreach ($managersToPropertysList as $x)
		{
		$managersToPropertysArray[$x->property_uid][]=(int)$x->manager_id;
		}
	$query="SELECT property_uid FROM #__jomres_managers_propertys_xref  WHERE manager_id = '".(int)$userid."'";
	$managersToPropertyList = doSelectSql($query);
	$managersToPropertyArray=array();
	foreach ($managersToPropertyList as $x)
		{
		$managersToPropertyArray[]=(int)$x->property_uid;
		}

	$image = "/components/com_jomres/images/jomresimages/small/Save.png";
	$image = str_replace('+' , '%20' , $image);
	$image = str_replace('%2F' , '/' , $image);

	$superPropertyManagerOutput=jomresHTML::selectList( $yesno, 'superpropertymanager','class="inputbox" size="1"', 'value', 'text', $superPropertyManager);

	$jrtbar = new jomres_toolbar();
	$jrtb  = $jrtbar->startTable();
	$link = $jomresConfig_live_siteJOMRES_ADMINISTRATORDIRECTORY."/index2.php?option=com_jomres";
	$jrtb .= $jrtbar->customToolbarItem('listMosUsers',$link,_JOMRES_COM_MR_SAVE,$submitOnClick=true,$submitTask="listMosUsers",$image);
	$jrtb .= $jrtbar->toolbarItem('cancel',"index2.php?option=com_jomres&task=listMosUsers",'');
	$jrtb .= $jrtbar->endTable();
	?>
	<script language="JavaScript" type="text/javascript">
	function SelectAll(CheckBoxControl)
		{
		if (CheckBoxControl.checked == true)
			{
			var i;
			for (i=0; i < document.forms[0].elements.length; i++)
				{
				if ((document.forms[0].elements[i].type == 'checkbox') && (document.forms[0].elements[i].name.indexOf('chosenHotel') > -1))
					{
					document.forms[0].elements[i].checked = true;
					}
				}
			}
		else
			{
			var i;
			for (i=0; i < document.forms[0].elements.length; i++)
				{
				if ((document.forms[0].elements[i].type == 'checkbox') && (document.forms[0].elements[i].name.indexOf('chosenHotel') > -1))
					{
					document.forms[0].elements[i].checked = false;
					}
				}
			}
		}
	</script>

	<form action="" method="post" name="adminForm">
	<?php
	echo $username;
	echo $jrtb;
	if ($accessLevel == 2)
		echo _JOMRES_COM_USERIS_SUPERPROPERTYMANAGER." ".$superPropertyManagerOutput;
	?>
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th class="title"><?php echo _JOMRES_COM_MR_ASSIGNUSER_CHANGEHOTEL; ?></td>
		</tr>
	</table>
	<table class="adminlist">
	<tr align="left"><th><input type="CheckBox" name="SelectAllCheckBox" onclick="SelectAll(this)"></th><th>&nbsp;</th></tr>
	<?php
	$n=count($propertyIdArray);
	for ($i = 0; $i < $n; $i++)
		{
		$propertyManagers="";
		$managers=$managersToPropertysArray[$i];
		if (count($managers)>0)
			{
			foreach ($managers as $m)
				{
				$propertyManagers = $managersArray[$m].", ";
				}
			}
		$row="0";
		if ($i % 2)
			$row="1";
		$checked="";
		if (in_array($propertyIdArray[$i] ,$managersToPropertyArray) )
			$checked="checked";
		echo "<tr class=\"row$row\"><td><input type=\"checkbox\" name=\"chosenHotel[]\" value=\"".$propertyIdArray[$i]."\" ".$checked.">".$propertynameArray[$i]."</td><td>$propertyManagers</td></tr>";
		}
	?>
	</table>
	<?php echo $username; echo $jrtb; ?>
	<input type="hidden" name="jomrestoken" value="<?php echo jomresSetToken();?>">
	<input type="hidden" name="task" value="listMosUsers">
	<input type="hidden" name="userid" value="<?php echo $userid;?>">
	</form>
	<?php
	}

/**
#
 * Changes a user's access level
#
 */
function changeUserAccessLevel()
	{
	$userid = jomresGetParam( $_REQUEST, 'userid', '' );
	$username = jomresGetParam( $_REQUEST, 'username', '' );
	// First lets get a list of the hotels
	$query="SELECT propertys_uid,property_name FROM #__jomres_propertys";
	$propertyList = doSelectSql($query);
	$propertyIdArray=array();
	$propertynameArray=array();
	foreach ($propertyList as $property)
		{
		$propertyIdArray[]=$property->propertys_uid;
		$propertynameArray[]=$property->property_name;
		}
		?>
		<script language="JavaScript" type="text/javascript">
		function validate(){
			document.adminForm.action = "index2.php?option=com_jomres&task=listMosUsers"
			document.adminForm.submit();
			}
		</script>
		<form action="" method="post" name="adminForm">
				<?php echo $username;?>
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
						   <tr>
								   <th class="title"><?php echo _JOMRES_COM_MR_ASSIGNUSER_CHANGEACCESSLEVEL;?></td>
							  </tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
							<tr><td><input type="radio" name="accessLevel" value="1"><?php echo _JOMRES_COM_MR_ASSIGNUSER_LEVEL_RECEPTION ?></td></tr>
							<tr><td><input type="radio" name="accessLevel" value="2"><?php echo _JOMRES_COM_MR_ASSIGNUSER_LEVEL_ADMIN ?></td></tr>
				   </table>
				<input type="button" name="send" value="<?php echo _JOMRES_COM_MR_ASSIGNUSER_CHANGEACCESSLEVEL;?>" class="button" onclick="validate()">
				<input type="hidden" name="userid" value="<?php echo $userid;?>">
				<input type="hidden" name="jomrestoken" value="<?php echo jomresSetToken();?>">
		</form>
		 <?php

		}

/**
#
 * Grants or removes a user's access to the system
#
 */
function grantMosUser()
	{
	$userid = jomresGetParam( $_GET, 'userid', '' );
	$grantAct = jomresGetParam( $_GET, 'grantAct', '' );
	$username = jomresGetParam( $_GET, 'username', '' );
	$apikey=createNewAPIKey();
	if ($grantAct=="y")
		$query="INSERT INTO #__jomres_managers (`userid`,`username`,`property_uid`,`access_level`,`currentproperty`,`apikey`)VALUES ('".(int)$userid."','$username','-1','1','-1','$apikey')";
	else
		$query="DELETE FROM #__jomres_managers WHERE userid = '".(int)$userid."'";
	if (doInsertSql($query,'') )
		jomresRedirect( "index2.php?option=com_jomres&task=listMosUsers",_JOMRES_COM_MR_ASSIGNUSER_USERMODIFIEDMESAGE );
	}

?>